/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.exceptions;

public interface DeadlockTimeoutRollbackMarker {
}

