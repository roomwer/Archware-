/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.exceptions;

public interface StreamingNotifiable {
    public void setWasStreamingResults();
}

