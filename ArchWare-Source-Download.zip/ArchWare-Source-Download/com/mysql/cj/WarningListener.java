/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj;

public interface WarningListener {
    public void warningEncountered(String var1);
}

