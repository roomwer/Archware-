/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.conf;

import java.util.Properties;

public interface ConnectionPropertiesTransform {
    public Properties transformProperties(Properties var1);
}

