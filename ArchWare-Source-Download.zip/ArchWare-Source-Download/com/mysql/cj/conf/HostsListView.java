/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.conf;

public enum HostsListView {
    ALL,
    SOURCES,
    REPLICAS;

}

