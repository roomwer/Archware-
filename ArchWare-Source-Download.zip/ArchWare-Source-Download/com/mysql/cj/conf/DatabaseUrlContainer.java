/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.conf;

public interface DatabaseUrlContainer {
    public String getDatabaseUrl();
}

