/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.xdevapi;

import com.mysql.cj.xdevapi.SqlResult;
import com.mysql.cj.xdevapi.Statement;

public interface SqlStatement
extends Statement<SqlStatement, SqlResult> {
}

