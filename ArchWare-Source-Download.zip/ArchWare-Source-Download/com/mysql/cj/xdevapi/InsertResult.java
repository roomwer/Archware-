/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.xdevapi;

import com.mysql.cj.xdevapi.Result;

public interface InsertResult
extends Result {
    public Long getAutoIncrementValue();
}

