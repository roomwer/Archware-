/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.xdevapi;

import com.mysql.cj.xdevapi.DbDoc;
import com.mysql.cj.xdevapi.FetchResult;
import com.mysql.cj.xdevapi.Result;

public interface DocResult
extends FetchResult<DbDoc>,
Result {
}

