/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.protocol;

public interface ProtocolEntity {
}

