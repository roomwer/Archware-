/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.protocol.x;

import com.mysql.cj.protocol.ProtocolEntity;

public class FetchDoneMoreResults
implements ProtocolEntity {
}

