/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.protocol.x;

public enum CompressionMode {
    MESSAGE,
    STREAM;

}

