/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.protocol.x;

import com.mysql.cj.QueryResult;
import com.mysql.cj.protocol.ProtocolEntity;

public class Ok
implements ProtocolEntity,
QueryResult {
}

