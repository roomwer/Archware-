/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.util;

public class TestUtils {
    public static void dumpTestcaseQuery(String query) {
        System.err.println(query);
    }
}

