/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj;

import java.util.Map;

public class LicenseConfiguration {
    public static void checkLicenseType(Map<String, String> serverVariables) {
    }

    private LicenseConfiguration() {
    }
}

