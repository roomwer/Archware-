/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj;

public interface PingTarget {
    public void doPing() throws Exception;
}

