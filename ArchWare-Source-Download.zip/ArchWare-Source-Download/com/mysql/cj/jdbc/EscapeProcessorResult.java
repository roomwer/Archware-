/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj.jdbc;

class EscapeProcessorResult {
    boolean callingStoredFunction = false;
    String escapedSql;
    byte usesVariables = 0;

    EscapeProcessorResult() {
    }
}

