/*
 * Decompiled with CFR 0.150.
 */
package com.mysql.cj;

import com.mysql.cj.AbstractQuery;
import com.mysql.cj.NativeSession;

public class SimpleQuery
extends AbstractQuery {
    public SimpleQuery(NativeSession sess) {
        super(sess);
    }
}

